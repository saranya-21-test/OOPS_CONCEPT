class bankaccount:
    def __init__(self,account_holder):
        self.account_holder=account_holder
        self.balance=0

    def deposit(self,amount):
        self.balance+=amount
        print(f"{self.account_holder} deposited ${amount}. current balance: ${self.balance}")

    def withdraw(self,amount):
        if amount > self.balance:
            print("Insufficient amount!")
        else:
            self.balance-=amount
            print(f"{self.account_holder} withdraw ${amount}. current balance: ${self.balance}")

#account1=bankaccount("saru")
#account2=bankaccount("prani")

#account1.deposit(100)
#account1.withdraw(50)
#account2.deposit(200)
#account2.withdraw(300)